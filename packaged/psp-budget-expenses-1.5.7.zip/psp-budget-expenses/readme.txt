=== Project Panorama - Budget & Expense Tracking ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://example.com/
Tags: comments, spam
Requires at least: 5.0
Tested up to: 5.1.1
Stable tag: 5.1.1
Requires PHP: 5.6.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Track project budget and expenses by category in Project Panorama.

== Description ==

Track project budget and expenses by category in Project Panorama.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/psp-budgeting` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->Plugin Name screen to configure the plugin
1. (Make your instructions match the desired user flow for activating and installing your plugin. Include any steps that might be needed for explanatory purposes)


== Changelog ==

= 1.5.8 =
* Allows for re-adding of permissions

= 1.5.7 =
* Fixes array string error

= 1.5.6 =
* Supports decimal places

= 1.5.5 =
* Conditionally shows the add expense button based on permission to edit expenses
* Fixes issue with role capabilities getting reset

= 1.5.4 =
* Fixes incorrect text_domain string

= 1.5.3 =
* Adds missing translation POT

= 1.5.2 =
* Fixes issue where marking task complete moves budget bar
* Fixes issue where percentage sign is on wrong side of number

= 1.5.1 =
* Support for Panorama 2.0
* Fixed issue where you could edit or delete expenses after adding

= 1.1 =
* Added setting for currency symbol

= 1.0.2 =
* Adds the ability to translate $ into different currency symbols

= 1.0 =
* First release!
