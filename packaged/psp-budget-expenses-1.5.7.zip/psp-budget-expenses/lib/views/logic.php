<?php
function pspb_get_template( $template = NULL ) {
    return PSPB_PATH . '/lib/views/templates/' . $template . '.php';
}
